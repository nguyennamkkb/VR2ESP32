/****************************************************************************
** Meta object code from reading C++ file 'fs01_qt.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fs01_qt.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fs01_qt.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_fs01_qt_t {
    QByteArrayData data[67];
    char stringdata0[575];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_fs01_qt_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_fs01_qt_t qt_meta_stringdata_fs01_qt = {
    {
QT_MOC_LITERAL(0, 0, 7), // "fs01_qt"
QT_MOC_LITERAL(1, 8, 10), // "closeEvent"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 12), // "QCloseEvent*"
QT_MOC_LITERAL(4, 33, 5), // "event"
QT_MOC_LITERAL(5, 39, 8), // "cfg_load"
QT_MOC_LITERAL(6, 48, 6), // "get_ip"
QT_MOC_LITERAL(7, 55, 6), // "Timer1"
QT_MOC_LITERAL(8, 62, 7), // "ui_init"
QT_MOC_LITERAL(9, 70, 11), // "new_udp_msg"
QT_MOC_LITERAL(10, 82, 8), // "response"
QT_MOC_LITERAL(11, 91, 14), // "new_serial_msg"
QT_MOC_LITERAL(12, 106, 1), // "s"
QT_MOC_LITERAL(13, 108, 11), // "serial_scan"
QT_MOC_LITERAL(14, 120, 14), // "new_string_msg"
QT_MOC_LITERAL(15, 135, 1), // "n"
QT_MOC_LITERAL(16, 137, 6), // "ba_str"
QT_MOC_LITERAL(17, 144, 2), // "ba"
QT_MOC_LITERAL(18, 147, 9), // "btn_click"
QT_MOC_LITERAL(19, 157, 1), // "k"
QT_MOC_LITERAL(20, 159, 8), // "fp_click"
QT_MOC_LITERAL(21, 168, 1), // "i"
QT_MOC_LITERAL(22, 170, 10), // "str_to_int"
QT_MOC_LITERAL(23, 181, 7), // "k_input"
QT_MOC_LITERAL(24, 189, 23), // "QInputDialog::InputMode"
QT_MOC_LITERAL(25, 213, 10), // "input_mode"
QT_MOC_LITERAL(26, 224, 10), // "prompt_txt"
QT_MOC_LITERAL(27, 235, 14), // "read_page_file"
QT_MOC_LITERAL(28, 250, 15), // "write_page_file"
QT_MOC_LITERAL(29, 266, 5), // "fname"
QT_MOC_LITERAL(30, 272, 7), // "msg_box"
QT_MOC_LITERAL(31, 280, 11), // "fp_btn_init"
QT_MOC_LITERAL(32, 292, 8), // "btn_name"
QT_MOC_LITERAL(33, 301, 8), // "cmd_send"
QT_MOC_LITERAL(34, 310, 3), // "cmd"
QT_MOC_LITERAL(35, 314, 10), // "txt_append"
QT_MOC_LITERAL(36, 325, 13), // "string_to_int"
QT_MOC_LITERAL(37, 339, 14), // "read_wave_file"
QT_MOC_LITERAL(38, 354, 9), // "encode_ba"
QT_MOC_LITERAL(39, 364, 3), // "seg"
QT_MOC_LITERAL(40, 368, 11), // "new_udp_str"
QT_MOC_LITERAL(41, 380, 10), // "voice_send"
QT_MOC_LITERAL(42, 391, 8), // "btn_list"
QT_MOC_LITERAL(43, 400, 8), // "Com_open"
QT_MOC_LITERAL(44, 409, 4), // "Scan"
QT_MOC_LITERAL(45, 414, 5), // "Clear"
QT_MOC_LITERAL(46, 420, 8), // "Identify"
QT_MOC_LITERAL(47, 429, 5), // "Count"
QT_MOC_LITERAL(48, 435, 6), // "Delete"
QT_MOC_LITERAL(49, 442, 5), // "Empty"
QT_MOC_LITERAL(50, 448, 6), // "Detect"
QT_MOC_LITERAL(51, 455, 8), // "Enroll_1"
QT_MOC_LITERAL(52, 464, 6), // "Enroll"
QT_MOC_LITERAL(53, 471, 7), // "Read_fp"
QT_MOC_LITERAL(54, 479, 6), // "Verify"
QT_MOC_LITERAL(55, 486, 6), // "Cancel"
QT_MOC_LITERAL(56, 493, 8), // "First_ID"
QT_MOC_LITERAL(57, 502, 10), // "Get_Enroll"
QT_MOC_LITERAL(58, 513, 8), // "Download"
QT_MOC_LITERAL(59, 522, 4), // "Play"
QT_MOC_LITERAL(60, 527, 3), // "Ev2"
QT_MOC_LITERAL(61, 531, 4), // "Ssid"
QT_MOC_LITERAL(62, 536, 6), // "Bip_on"
QT_MOC_LITERAL(63, 543, 7), // "Ip_Show"
QT_MOC_LITERAL(64, 551, 4), // "List"
QT_MOC_LITERAL(65, 556, 8), // "Set_pass"
QT_MOC_LITERAL(66, 565, 9) // "Veri_pass"

    },
    "fs01_qt\0closeEvent\0\0QCloseEvent*\0event\0"
    "cfg_load\0get_ip\0Timer1\0ui_init\0"
    "new_udp_msg\0response\0new_serial_msg\0"
    "s\0serial_scan\0new_string_msg\0n\0ba_str\0"
    "ba\0btn_click\0k\0fp_click\0i\0str_to_int\0"
    "k_input\0QInputDialog::InputMode\0"
    "input_mode\0prompt_txt\0read_page_file\0"
    "write_page_file\0fname\0msg_box\0fp_btn_init\0"
    "btn_name\0cmd_send\0cmd\0txt_append\0"
    "string_to_int\0read_wave_file\0encode_ba\0"
    "seg\0new_udp_str\0voice_send\0btn_list\0"
    "Com_open\0Scan\0Clear\0Identify\0Count\0"
    "Delete\0Empty\0Detect\0Enroll_1\0Enroll\0"
    "Read_fp\0Verify\0Cancel\0First_ID\0"
    "Get_Enroll\0Download\0Play\0Ev2\0Ssid\0"
    "Bip_on\0Ip_Show\0List\0Set_pass\0Veri_pass"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_fs01_qt[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      27,   14, // methods
       0,    0, // properties
       1,  222, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  149,    2, 0x08 /* Private */,
       5,    0,  152,    2, 0x08 /* Private */,
       6,    0,  153,    2, 0x08 /* Private */,
       7,    0,  154,    2, 0x08 /* Private */,
       8,    0,  155,    2, 0x08 /* Private */,
       9,    1,  156,    2, 0x08 /* Private */,
      11,    1,  159,    2, 0x08 /* Private */,
      11,    1,  162,    2, 0x08 /* Private */,
      13,    0,  165,    2, 0x08 /* Private */,
      14,    2,  166,    2, 0x08 /* Private */,
      16,    1,  171,    2, 0x08 /* Private */,
      18,    1,  174,    2, 0x08 /* Private */,
      20,    1,  177,    2, 0x08 /* Private */,
      22,    1,  180,    2, 0x08 /* Private */,
      23,    2,  183,    2, 0x08 /* Private */,
      27,    0,  188,    2, 0x08 /* Private */,
      28,    2,  189,    2, 0x08 /* Private */,
      30,    1,  194,    2, 0x08 /* Private */,
      31,    0,  197,    2, 0x08 /* Private */,
      32,    1,  198,    2, 0x08 /* Private */,
      33,    1,  201,    2, 0x08 /* Private */,
      35,    1,  204,    2, 0x08 /* Private */,
      36,    1,  207,    2, 0x08 /* Private */,
      37,    0,  210,    2, 0x08 /* Private */,
      38,    2,  211,    2, 0x08 /* Private */,
      40,    2,  216,    2, 0x08 /* Private */,
      41,    0,  221,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Short,   10,
    QMetaType::Void, QMetaType::Short,   10,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Short, QMetaType::QString,   15,   12,
    QMetaType::QString, QMetaType::QByteArray,   17,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Short, QMetaType::QString,   12,
    QMetaType::Void, 0x80000000 | 24, QMetaType::QString,   25,   26,
    QMetaType::QByteArray,
    QMetaType::Void, QMetaType::QString, QMetaType::QByteArray,   29,   17,
    QMetaType::Short, QMetaType::QString,   12,
    QMetaType::Void,
    QMetaType::QString, QMetaType::Short,   21,
    QMetaType::Void, QMetaType::Short,   34,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Short, QMetaType::QString,   12,
    QMetaType::QByteArray,
    QMetaType::Void, QMetaType::QByteArray, QMetaType::Int,   17,   39,
    QMetaType::Void, QMetaType::Short, QMetaType::QString,   10,   12,
    QMetaType::Void,

 // enums: name, flags, count, data
      42, 0x0,   24,  226,

 // enum data: key, value
      43, uint(fs01_qt::Com_open),
      44, uint(fs01_qt::Scan),
      45, uint(fs01_qt::Clear),
      46, uint(fs01_qt::Identify),
      47, uint(fs01_qt::Count),
      48, uint(fs01_qt::Delete),
      49, uint(fs01_qt::Empty),
      50, uint(fs01_qt::Detect),
      51, uint(fs01_qt::Enroll_1),
      52, uint(fs01_qt::Enroll),
      53, uint(fs01_qt::Read_fp),
      54, uint(fs01_qt::Verify),
      55, uint(fs01_qt::Cancel),
      56, uint(fs01_qt::First_ID),
      57, uint(fs01_qt::Get_Enroll),
      58, uint(fs01_qt::Download),
      59, uint(fs01_qt::Play),
      60, uint(fs01_qt::Ev2),
      61, uint(fs01_qt::Ssid),
      62, uint(fs01_qt::Bip_on),
      63, uint(fs01_qt::Ip_Show),
      64, uint(fs01_qt::List),
      65, uint(fs01_qt::Set_pass),
      66, uint(fs01_qt::Veri_pass),

       0        // eod
};

void fs01_qt::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        fs01_qt *_t = static_cast<fs01_qt *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        case 1: _t->cfg_load(); break;
        case 2: _t->get_ip(); break;
        case 3: _t->Timer1(); break;
        case 4: _t->ui_init(); break;
        case 5: _t->new_udp_msg((*reinterpret_cast< qint16(*)>(_a[1]))); break;
        case 6: _t->new_serial_msg((*reinterpret_cast< qint16(*)>(_a[1]))); break;
        case 7: _t->new_serial_msg((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->serial_scan(); break;
        case 9: _t->new_string_msg((*reinterpret_cast< qint16(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 10: { QString _r = _t->ba_str((*reinterpret_cast< QByteArray(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 11: _t->btn_click((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->fp_click((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: { qint16 _r = _t->str_to_int((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< qint16*>(_a[0]) = _r; }  break;
        case 14: _t->k_input((*reinterpret_cast< QInputDialog::InputMode(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 15: { QByteArray _r = _t->read_page_file();
            if (_a[0]) *reinterpret_cast< QByteArray*>(_a[0]) = _r; }  break;
        case 16: _t->write_page_file((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QByteArray(*)>(_a[2]))); break;
        case 17: { qint16 _r = _t->msg_box((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< qint16*>(_a[0]) = _r; }  break;
        case 18: _t->fp_btn_init(); break;
        case 19: { QString _r = _t->btn_name((*reinterpret_cast< qint16(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 20: _t->cmd_send((*reinterpret_cast< qint16(*)>(_a[1]))); break;
        case 21: _t->txt_append((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 22: { qint16 _r = _t->string_to_int((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< qint16*>(_a[0]) = _r; }  break;
        case 23: { QByteArray _r = _t->read_wave_file();
            if (_a[0]) *reinterpret_cast< QByteArray*>(_a[0]) = _r; }  break;
        case 24: _t->encode_ba((*reinterpret_cast< QByteArray(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 25: _t->new_udp_str((*reinterpret_cast< qint16(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 26: _t->voice_send(); break;
        default: ;
        }
    }
}

const QMetaObject fs01_qt::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_fs01_qt.data,
      qt_meta_data_fs01_qt,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *fs01_qt::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *fs01_qt::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_fs01_qt.stringdata0))
        return static_cast<void*>(const_cast< fs01_qt*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int fs01_qt::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 27)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 27;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
