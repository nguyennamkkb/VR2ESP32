/****************************************************************************
** Meta object code from reading C++ file 'fs_01.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fs_01.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fs_01.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_fs_01_t {
    QByteArrayData data[56];
    char stringdata0[620];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_fs_01_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_fs_01_t qt_meta_stringdata_fs_01 = {
    {
QT_MOC_LITERAL(0, 0, 5), // "fs_01"
QT_MOC_LITERAL(1, 6, 12), // "enumToString"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 3), // "cmd"
QT_MOC_LITERAL(4, 24, 12), // "fp_btn_check"
QT_MOC_LITERAL(5, 37, 10), // "ba_to_send"
QT_MOC_LITERAL(6, 48, 3), // "len"
QT_MOC_LITERAL(7, 52, 7), // "page_id"
QT_MOC_LITERAL(8, 60, 10), // "get_tx_cks"
QT_MOC_LITERAL(9, 71, 10), // "get_rx_cks"
QT_MOC_LITERAL(10, 82, 7), // "fix_len"
QT_MOC_LITERAL(11, 90, 1), // "n"
QT_MOC_LITERAL(12, 92, 1), // "k"
QT_MOC_LITERAL(13, 94, 12), // "ba_to_string"
QT_MOC_LITERAL(14, 107, 2), // "ba"
QT_MOC_LITERAL(15, 110, 13), // "return_string"
QT_MOC_LITERAL(16, 124, 8), // "ret_code"
QT_MOC_LITERAL(17, 133, 9), // "fs01_code"
QT_MOC_LITERAL(18, 143, 6), // "Verify"
QT_MOC_LITERAL(19, 150, 8), // "Identify"
QT_MOC_LITERAL(20, 159, 8), // "Enroll_3"
QT_MOC_LITERAL(21, 168, 8), // "Enroll_1"
QT_MOC_LITERAL(22, 177, 11), // "Delete_Page"
QT_MOC_LITERAL(23, 189, 5), // "Empty"
QT_MOC_LITERAL(24, 195, 12), // "Get_Empty_ID"
QT_MOC_LITERAL(25, 208, 12), // "Get_Page_Sta"
QT_MOC_LITERAL(26, 221, 15), // "Get_Broken_Page"
QT_MOC_LITERAL(27, 237, 9), // "Read_Page"
QT_MOC_LITERAL(28, 247, 10), // "Write_Page"
QT_MOC_LITERAL(29, 258, 12), // "Set_Security"
QT_MOC_LITERAL(30, 271, 12), // "Get_Security"
QT_MOC_LITERAL(31, 284, 12), // "Set_Time_Out"
QT_MOC_LITERAL(32, 297, 12), // "Get_Time_Out"
QT_MOC_LITERAL(33, 310, 13), // "Set_Device_ID"
QT_MOC_LITERAL(34, 324, 13), // "Get_Device_ID"
QT_MOC_LITERAL(35, 338, 14), // "Get_FW_Version"
QT_MOC_LITERAL(36, 353, 13), // "Finger_Detect"
QT_MOC_LITERAL(37, 367, 12), // "Set_BaudRate"
QT_MOC_LITERAL(38, 380, 13), // "Set_Dup_Check"
QT_MOC_LITERAL(39, 394, 13), // "Get_Dup_Check"
QT_MOC_LITERAL(40, 408, 11), // "Stadby_Mode"
QT_MOC_LITERAL(41, 420, 10), // "Enroll_RAM"
QT_MOC_LITERAL(42, 431, 10), // "Get_Enroll"
QT_MOC_LITERAL(43, 442, 11), // "Get_Feature"
QT_MOC_LITERAL(44, 454, 14), // "Verify_Feature"
QT_MOC_LITERAL(45, 469, 16), // "Identify_Feature"
QT_MOC_LITERAL(46, 486, 15), // "Get_Device_Name"
QT_MOC_LITERAL(47, 502, 11), // "LED_Control"
QT_MOC_LITERAL(48, 514, 13), // "Identify_Free"
QT_MOC_LITERAL(49, 528, 7), // "Set_Psw"
QT_MOC_LITERAL(50, 536, 10), // "Verify_Psw"
QT_MOC_LITERAL(51, 547, 16), // "Get_Enroll_Count"
QT_MOC_LITERAL(52, 564, 11), // "Change_Page"
QT_MOC_LITERAL(53, 576, 9), // "FP_Cancel"
QT_MOC_LITERAL(54, 586, 15), // "Test_Connection"
QT_MOC_LITERAL(55, 602, 17) // "Incorrect_Command"

    },
    "fs_01\0enumToString\0\0cmd\0fp_btn_check\0"
    "ba_to_send\0len\0page_id\0get_tx_cks\0"
    "get_rx_cks\0fix_len\0n\0k\0ba_to_string\0"
    "ba\0return_string\0ret_code\0fs01_code\0"
    "Verify\0Identify\0Enroll_3\0Enroll_1\0"
    "Delete_Page\0Empty\0Get_Empty_ID\0"
    "Get_Page_Sta\0Get_Broken_Page\0Read_Page\0"
    "Write_Page\0Set_Security\0Get_Security\0"
    "Set_Time_Out\0Get_Time_Out\0Set_Device_ID\0"
    "Get_Device_ID\0Get_FW_Version\0Finger_Detect\0"
    "Set_BaudRate\0Set_Dup_Check\0Get_Dup_Check\0"
    "Stadby_Mode\0Enroll_RAM\0Get_Enroll\0"
    "Get_Feature\0Verify_Feature\0Identify_Feature\0"
    "Get_Device_Name\0LED_Control\0Identify_Free\0"
    "Set_Psw\0Verify_Psw\0Get_Enroll_Count\0"
    "Change_Page\0FP_Cancel\0Test_Connection\0"
    "Incorrect_Command"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_fs_01[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       1,   82, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   54,    2, 0x0a /* Public */,
       4,    0,   57,    2, 0x0a /* Public */,
       5,    3,   58,    2, 0x0a /* Public */,
       8,    1,   65,    2, 0x0a /* Public */,
       9,    1,   68,    2, 0x0a /* Public */,
      10,    2,   71,    2, 0x0a /* Public */,
      13,    1,   76,    2, 0x0a /* Public */,
      15,    1,   79,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::QString, QMetaType::Short,    3,
    QMetaType::Void,
    QMetaType::QByteArray, QMetaType::Short, QMetaType::Short, QMetaType::Short,    3,    6,    7,
    QMetaType::QByteArray, QMetaType::Short,    6,
    QMetaType::Bool, QMetaType::Short,    6,
    QMetaType::QString, QMetaType::Short, QMetaType::Short,   11,   12,
    QMetaType::QString, QMetaType::QByteArray,   14,
    QMetaType::QString, QMetaType::Short,   16,

 // enums: name, flags, count, data
      17, 0x0,   38,   86,

 // enum data: key, value
      18, uint(fs_01::Verify),
      19, uint(fs_01::Identify),
      20, uint(fs_01::Enroll_3),
      21, uint(fs_01::Enroll_1),
      22, uint(fs_01::Delete_Page),
      23, uint(fs_01::Empty),
      24, uint(fs_01::Get_Empty_ID),
      25, uint(fs_01::Get_Page_Sta),
      26, uint(fs_01::Get_Broken_Page),
      27, uint(fs_01::Read_Page),
      28, uint(fs_01::Write_Page),
      29, uint(fs_01::Set_Security),
      30, uint(fs_01::Get_Security),
      31, uint(fs_01::Set_Time_Out),
      32, uint(fs_01::Get_Time_Out),
      33, uint(fs_01::Set_Device_ID),
      34, uint(fs_01::Get_Device_ID),
      35, uint(fs_01::Get_FW_Version),
      36, uint(fs_01::Finger_Detect),
      37, uint(fs_01::Set_BaudRate),
      38, uint(fs_01::Set_Dup_Check),
      39, uint(fs_01::Get_Dup_Check),
      40, uint(fs_01::Stadby_Mode),
      41, uint(fs_01::Enroll_RAM),
      42, uint(fs_01::Get_Enroll),
      43, uint(fs_01::Get_Feature),
      44, uint(fs_01::Verify_Feature),
      45, uint(fs_01::Identify_Feature),
      46, uint(fs_01::Get_Device_Name),
      47, uint(fs_01::LED_Control),
      48, uint(fs_01::Identify_Free),
      49, uint(fs_01::Set_Psw),
      50, uint(fs_01::Verify_Psw),
      51, uint(fs_01::Get_Enroll_Count),
      52, uint(fs_01::Change_Page),
      53, uint(fs_01::FP_Cancel),
      54, uint(fs_01::Test_Connection),
      55, uint(fs_01::Incorrect_Command),

       0        // eod
};

void fs_01::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        fs_01 *_t = static_cast<fs_01 *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: { QString _r = _t->enumToString((*reinterpret_cast< qint16(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 1: _t->fp_btn_check(); break;
        case 2: { QByteArray _r = _t->ba_to_send((*reinterpret_cast< qint16(*)>(_a[1])),(*reinterpret_cast< qint16(*)>(_a[2])),(*reinterpret_cast< qint16(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< QByteArray*>(_a[0]) = _r; }  break;
        case 3: { QByteArray _r = _t->get_tx_cks((*reinterpret_cast< qint16(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QByteArray*>(_a[0]) = _r; }  break;
        case 4: { bool _r = _t->get_rx_cks((*reinterpret_cast< qint16(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 5: { QString _r = _t->fix_len((*reinterpret_cast< qint16(*)>(_a[1])),(*reinterpret_cast< qint16(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 6: { QString _r = _t->ba_to_string((*reinterpret_cast< QByteArray(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 7: { QString _r = _t->return_string((*reinterpret_cast< qint16(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObject fs_01::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_fs_01.data,
      qt_meta_data_fs_01,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *fs_01::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *fs_01::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_fs_01.stringdata0))
        return static_cast<void*>(const_cast< fs_01*>(this));
    return QObject::qt_metacast(_clname);
}

int fs_01::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
